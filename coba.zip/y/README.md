# Sam Kira Kun

<h1 align="center">SAM KIRA KUN<br></h1>


[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/blackpirateapps/a-bot-for-sam/)
